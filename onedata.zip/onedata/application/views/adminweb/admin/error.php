<div class="row-fluid">
					<div class="span12 page-404">
						<div class="number">
							404
						</div>
						<div class="details">
							<h3>Oops! Image file is too large.</h3>
							
							<form action="#">
								<div class="input-append">                      
									
									<a href="<?php echo base_url();?>adminweb/admin" class="btn green"><i class="icon-long-arrow-left"></i> Return Add admin</a>
								</div>
							</form>
						</div>
					</div>
				</div>